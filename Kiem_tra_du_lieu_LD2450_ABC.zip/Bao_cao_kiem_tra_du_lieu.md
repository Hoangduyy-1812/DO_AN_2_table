# Kiểm tra bộ dữ liệu LD2450–ESP32

Ngày kiểm tra: 03/11/2026 (Việt Nam). Nguồn: tệp người dùng gửi `data(1).rar`.

## Kết luận

Đã đủ danh mục thu ban đầu: 3 vị trí × 8 kịch bản × 3 lần = 72 lần có người, cộng 3 lần phòng trống, tổng 75 lần thu. Có đủ dữ liệu để bắt đầu làm sạch, gắn nhãn và xây dựng mô hình thử nghiệm. Chưa đủ căn cứ công bố độ chính xác phân loại hoặc xác suất bảo vệ thành công 90–95%.

Không cần quyết định thu lại toàn bộ ngay. Cần xử lý dữ liệu tồn hàng đợi, xác minh mục tiêu và bổ sung nhãn thời gian trước khi train/test.

## 1. Danh mục đã kiểm tra

| Kịch bản | A | B | C | Phòng trống |
|---|---:|---:|---:|---:|
| Cúi nhặt đồ | 3 | 3 | 3 | 0 |
| Đi lại (C đặt tên di_chuyen) | 3 | 3 | 3 | 0 |
| Đứng–ngồi | 3 | 3 | 3 | 0 |
| Đứng–ngồi nhanh | 3 | 3 | 3 | 0 |
| Đứng yên | 3 | 3 | 3 | 0 |
| Nằm chủ động | 3 | 3 | 3 | 0 |
| Ngã mô phỏng | 3 | 3 | 3 | 0 |
| Ngồi xổm | 3 | 3 | 3 | 0 |
| Phòng trống | 0 | 0 | 0 | 3 |

Cả 75 thư mục đều có `metadata.json`, `receiver_summary.json`, `samples.csv`, `raw.ndjson` (300 tệp). C có tên `di_chuyen`, được gộp cùng kịch bản `di_lai` trong bảng kiểm tra; không sửa bản gốc.

## 2. Kết quả kiểm tra định lượng

- 70.941 dòng khung radar; tổng thời gian PC ghi nhận trong từng file khoảng 93,47 phút (không tính khoảng nghỉ giữa các lần thu).
- Đối chiếu toàn bộ 70.941 raw frame với CSV: số lượng, seq, t_us, raw_hex khớp hoàn toàn.
- 0 raw frame sai độ dài/header/tail; 0 trường tọa độ, tốc độ, độ phân giải giải mã khác CSV. Kiểm tra độc lập cả ba ô mục tiêu theo quy ước dấu của giao thức.
- bad_tails, discarded_bytes, uart_overflows, uart_line_errors đều bằng 0 trong dữ liệu đã lưu.
- Không có khóa `(device_id, boot_id, seq)` trùng giữa các file.
- Khoảng lấy mẫu điển hình theo ESP32 khoảng 88,98–88,99 ms, tương đương khoảng 11,24 Hz thực tế; không ép dữ liệu thành 10 Hz.

## 3. Dữ liệu cũ / trễ cần cách ly

`backlog_ms = (sent_us - t_us)/1000` là trễ từ thời điểm ESP32 nhận khung tới lúc gửi. Dữ liệu tồn trước khi PC bắt đầu thu có thể bị gửi dồn vào file mới. Đây là vấn đề hàng đợi/thời gian, không phải bằng chứng nhiễu RF.

- Ngưỡng kiểm tra sơ bộ: cách ly bản ghi `backlog_ms > 500`. Đây là ngưỡng kỹ thuật phục vụ kiểm tra, chưa phải ngưỡng đã tối ưu hoặc nhãn khung hỏng.
- 11.719/70.941 dòng (16,52%) vượt ngưỡng; còn 59.222 dòng dưới hoặc bằng ngưỡng.
- Tất cả 75 file đều bắt đầu với một phần bản ghi trễ theo ngưỡng trên. Không được gắn nhãn toàn file chỉ bằng tên thư mục.
- Ví dụ `A_nga_mo_phong_01`: bản ghi đầu trễ 41,33 giây.
- Ví dụ `A_nga_mo_phong_03`: bản ghi đầu trễ 814,60 giây (~13,58 phút).
- Ví dụ `A_dung_yen_03`: bản ghi đầu trễ 3.025,72 giây (~50,43 phút).
- 59 file có nhảy seq khi xét toàn bộ bản ghi; tổng số thứ tự bị bỏ qua là 90.844. Phần lớn liên quan tới việc đi từ khung tồn cũ sang khung mới: không được dùng tổng này làm tỷ lệ mất khung trong động tác hiện tại.
- Bộ đếm queue_drops tăng trong 23 file, tổng mức tăng 465. Chưa có mã firmware để kết luận chính xác cơ chế bỏ khung.
- Giữa hai dòng liền kề trong CSV mà cả hai đều có backlog_ms <= 500, không thấy seq bị bỏ qua. Khi tách theo tính liên tục, tổng thời lượng các đoạn đạt điều kiện khoảng 87,70 phút. Con số này không xác nhận nhãn hay mục tiêu đúng.
- Các đoạn cách ly có thể xuất hiện giữa file: không chỉ cắt một số giây cố định đầu/cuối. Không nội suy qua chỗ đứt rồi coi đó là động tác thật.

Cần dùng trục thời gian ESP32 `t_us` để xem hình dạng chuyển động. Nhãn từ video/giờ PC cần đồng bộ với thời gian này; không coi thời điểm PC nhận là thời điểm đo khi có backlog lớn.

## 4. Phòng trống và chọn mục tiêu

Trong phần bản ghi backlog <= 500 ms:

| File | Tỷ lệ khung có active_count > 0 |
|---|---:|
| phong_trong_01 | 53,07% |
| phong_trong_02 | 100,00% |
| phong_trong_03 | 100,00% |

Bỏ thêm 20 giây đầu của phần mới vẫn còn tỷ lệ tương ứng khoảng 35,64%, 100%, 100%. Vì vậy hiện tượng không chỉ nằm ở vài giây chuẩn bị đầu file.

Chưa thể khẳng định nguyên nhân là người khác, phản xạ, đồ vật chuyển động, xuyên vật cản hay thuật toán radar. Nếu phòng thực sự không có người trong vùng quan sát, đây là dữ liệu âm tính khó/khả năng báo mục tiêu giả cần điều tra; không được suy ra active_count > 0 đồng nghĩa chắc chắn có người.

26/75 file (24/72 file có người) có lúc báo từ hai ô mục tiêu hoạt động trở lên trong phần mới. Ví dụ `A_dung_ngoi_nhanh_01` có khoảng 96,97% dòng mới báo >=2 mục tiêu. Điều này không chứng minh có hai người, nhưng bắt buộc kiểm tra lựa chọn mục tiêu. Slot 1/2/3 không phải danh tính người cố định; không mặc định t1 luôn là người làm động tác.

## 5. Tín hiệu hoạt động có ích, nhưng chưa có ground truth theo thời gian

Biểu đồ X/Y của các file `_01` cho thấy nhiều chuỗi chuyển động lặp lại và các mức tọa độ khác nhau. Các file ngã có các đoạn tọa độ X cao–thấp lặp lại; file nằm chủ động cũng có diễn biến tương tự. Đây là cơ sở để phát triển đặc trưng theo thời gian, không chứng minh đã phân loại đúng.

Không gọi tọa độ X là chiều cao cơ thể khi chưa hiệu chuẩn hướng lắp. Tệp không ghi chiều cao lắp, góc nghiêng, góc xoay hoặc tọa độ thực của A/B/C. Do đó chỉ xác nhận được đủ thư mục A/B/C, chưa xác nhận được chúng đúng 2 m, 1,5 m, 2 m lệch trái ngoài thực tế.

Metadata của toàn bộ 75 lần đều dùng participant=P01, trial_id=T001; trial_activity là pilot (69 file) hoặc pilot\ (6 file), notes rỗng. Không có video hay bảng nhãn thời điểm trong gói nén. Cần dùng tên thư mục làm mã lần thử duy nhất, thay vì trial_id=T001.

Cần nhãn PREPARE/IGNORE, STAND, SIT_DOWN, SIT, STAND_UP, BEND, SQUAT, LIE_DOWN, LYING, FALL, GET_UP, WALK, EMPTY, UNKNOWN theo diễn biến thực tế. Lựa chọn nhãn theo quan sát, không lấy vận tốc bằng 0 làm bằng chứng ngã. Tình trạng track mất phải lưu riêng với nhãn hoạt động.

Một file có thể chứa nhiều chu kỳ; 9 file ngã không đồng nghĩa chính xác 9 sự kiện ngã. Chưa đếm sự kiện khi không có nhãn tham chiếu.

## 6. Chia tập theo thỏa thuận của người dùng

`split_manifest.csv` giữ lần 01/02 làm TRAIN_DEVELOPMENT và lần 03 làm TEST_RESERVED, cho từng vị trí và kịch bản. Có 50 file phát triển (48 có người + 2 phòng trống), 25 file giữ riêng (24 có người + 1 phòng trống).

Đây chỉ là bảng chia theo thư mục, chưa là tập train có nhãn động tác. Không huấn luyện hoặc tối ưu mô hình trong lần kiểm tra này; file `_03` chỉ được kiểm tra chất lượng kỹ thuật. Biểu đồ so sánh hoạt động chỉ dùng `_01`.

Chia theo file/buổi trước khi cắt cửa sổ, giữ mọi cửa sổ trong cùng một file ở một phía. Khi điều chỉnh mô hình, dùng phần phát triển; không dùng test cuối để chọn ngưỡng. Kiểm tra mới ở buổi khác và/hoặc người khác khi muốn đánh giá khả năng tổng quát hóa.

## 7. Việc nên làm tiếp

1. Giữ nguyên dữ liệu gốc. Khi mở phiên ghi mới, chờ xả dữ liệu cũ hoặc sửa cơ chế hàng đợi; chỉ bắt đầu kịch bản khi dữ liệu mới đã tới đều. Không xóa khung cũ rồi giả vờ thời gian liên tục.
2. Xác minh ba file phòng trống và các file báo nhiều mục tiêu; kiểm tra bố trí radar và mục tiêu thực hiện. Chỉ thu bổ sung những đoạn không thể xác minh, không mặc định thu lại cả 75 lần.
3. Bổ sung mốc hành động từ video/ghi chú đồng bộ. Nếu không có tham chiếu đáng tin cậy, đánh dấu UNKNOWN và thu bổ sung vài lần có video cho đánh giá cuối. Không tự đặt nhãn từ đồ thị rồi dùng chính nhãn đó chứng minh độ chính xác.
4. Xây baseline trên phần phát triển, sau đó đánh giá trên test có nhãn: số sự kiện ngã phát hiện đúng/bỏ sót, báo nhầm trong hoạt động thường ngày, độ trễ và confusion matrix khi thích hợp.

## 8. Đánh giá khả năng hoàn thành

Bằng chứng đã mạnh hơn: thay vì vài ví dụ riêng lẻ, đã có 75 lần thu ở ba nhóm vị trí và dữ liệu raw kiểm tra được. Đây là bước tiến thực chất cho PoC.

Chưa thể tính xác suất hoàn thành/bảo vệ thành công tăng bao nhiêu điểm phần trăm; cũng chưa có độ chính xác mô hình. Không chuyển tỷ lệ khung đúng cấu trúc thành tỷ lệ phát hiện ngã. Kết luận hiện tại: đủ dữ liệu để bước sang làm sạch, gắn nhãn và thử mô hình; độ tin cậy nhận diện còn phải đo bằng kiểm thử độc lập.

## Các tệp kèm theo

- quality_by_trial.csv: bảng kiểm tra 75 lần thu, gồm trễ, số mục tiêu, nhảy seq và bộ đếm.
- fresh_contiguous_segments.csv: các đoạn liên tục đạt điều kiện backlog <=500 ms, dài >=2 giây; không phải nhãn hành động.
- split_manifest.csv: chia phát triển/test theo lần thu.
- phase_labels_template.csv: bảng trống để điền nhãn thời gian, chưa có ground truth.
- traces_x.png, traces_y.png: biểu đồ lần 01 của ngã, nằm chủ động, cúi, ngồi nhanh ở A/B/C; các màu là ô mục tiêu, không phải danh tính người.
- empty_room_targets.png: số mục tiêu trong ba file phòng trống; vùng xám là dữ liệu trễ.

Không sửa nội dung tệp gốc trong data(1).rar.
