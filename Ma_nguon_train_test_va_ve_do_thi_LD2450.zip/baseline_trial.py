"""Trial-level LD2450 benchmark; not a live fall alarm or window-level model.
Fixed protocol: repeat 01/02 development, repeat 03 held out; no test tuning.
"""
from pathlib import Path
import argparse,json,sys
import numpy as np,pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score,balanced_accuracy_score,precision_score,recall_score,f1_score,confusion_matrix
from sklearn.model_selection import LeaveOneGroupOut
import sklearn,joblib

H_MM=1700.0
MAX_BACKLOG_MS=500.0
MIN_USABLE_ROWS=100

def feature_vector(path):
    d=pd.read_csv(path)
    # Ignore ambiguous multi-slot frames rather than assuming slot 1 identifies a person.
    mask=d.backlog_ms.le(MAX_BACKLOG_MS)&d.active_count.eq(1)
    x=np.full(len(d),np.nan);v=x.copy();slot=np.zeros(len(d),int)
    for s in (1,2,3):
        m=(mask&d[f't{s}_active'].eq(1)).to_numpy()
        x[m]=d.loc[m,f't{s}_x_mm'];v[m]=d.loc[m,f't{s}_speed_cms']/100.0;slot[m]=s
    valid=np.isfinite(x)&np.isfinite(v)
    usable=int(valid.sum())
    quality={'total_rows':len(d),'usable_rows':usable,'usable_fraction':float(valid.mean())}
    if usable<MIN_USABLE_ROWS:return None,quality
    t=d.t_us.to_numpy()/1e6
    z=(H_MM-x)/1000.0  # Proxy height of tracked return; do not clamp negative values.
    # Never bridge gaps, slot changes, or excluded records.
    boundary=(~valid)|np.r_[True,~valid[:-1]]|np.r_[True,np.diff(d.seq.to_numpy())!=1]|np.r_[True,np.diff(t)>.2]|np.r_[True,np.diff(slot)!=0]
    group=np.cumsum(boundary)
    zz=[];vv=[];rates=[];lagchanges=[];longest_low=0.
    for g in np.unique(group[valid]):
        inds=np.flatnonzero(valid&(group==g));tt=t[inds]
        # Causal 3-point median, independently inside each continuous segment.
        h=pd.Series(z[inds]).rolling(3,min_periods=1).median().to_numpy()
        zz.extend(h);vv.extend(np.abs(v[inds]))
        if len(inds)>1:
            rates.extend(np.diff(h)/np.diff(tt))
        start=None
        for k in range(len(h)):
            if h[k]<=.5:
                if start is None:start=k
                longest_low=max(longest_low,float(tt[k]-tt[start]))
            else:start=None
            j=np.searchsorted(tt,tt[k]-1.,side='right')-1
            if j>=0 and .8<=tt[k]-tt[j]<=1.2:lagchanges.append(float(h[k]-h[j]))
    zz=np.asarray(zz);vv=np.asarray(vv);rates=np.asarray(rates);lags=np.asarray(lagchanges)
    feats={f'z_q{q:02}':float(np.quantile(zz,q/100)) for q in [5,25,50,75,95]}
    feats['z_iqr']=float(np.quantile(zz,.75)-np.quantile(zz,.25))
    for q in [50,90,95]:feats[f'abs_speed_q{q}']=float(np.quantile(vv,q/100))
    for q in [5,50,95]:feats[f'dz_dt_q{q:02}']=float(np.quantile(rates,q/100)) if len(rates) else 0.
    for q in [5,95]:feats[f'dz_1s_q{q:02}']=float(np.quantile(lags,q/100)) if len(lags) else 0.
    for cm in [30,50,80]:feats[f'fraction_z_le_{cm}cm']=float(np.mean(zz<=cm/100))
    feats['longest_z_le_50cm_s']=longest_low
    return feats,quality

def factories():
    # Fixed in advance, without inspection of repeat-03 predictions.
    return {
      'RandomForest':lambda:RandomForestClassifier(n_estimators=300,max_depth=4,min_samples_leaf=2,class_weight='balanced_subsample',random_state=20261103,n_jobs=1),
      'SVM_RBF':lambda:make_pipeline(StandardScaler(),SVC(C=1.,kernel='rbf',gamma='scale',class_weight='balanced')),
    }

def metrics(y,p):
    return dict(n=len(y),accuracy=float(accuracy_score(y,p)),balanced_accuracy=float(balanced_accuracy_score(y,p)),precision_fall=float(precision_score(y,p,zero_division=0)),recall_fall=float(recall_score(y,p,zero_division=0)),f1_fall=float(f1_score(y,p,zero_division=0)),confusion_matrix=confusion_matrix(y,p,labels=[0,1]).tolist())

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data-root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    records=[];excluded=[]
    for p in sorted(a.data_root.rglob('samples.csv')):
        name=p.parent.name
        if len(name)<4 or name[0] not in 'ABC' or name[1]!='_':continue
        repeat=int(name[-2:]);activity=name[2:-3].replace('di_chuyen','di_lai')
        feats,q=feature_vector(p)
        base=dict(trial=name,position=name[0],repeat=repeat,scenario=activity,y=int(activity=='nga_mo_phong'),split='test' if repeat==3 else 'development')
        if feats is None:excluded.append(dict(**base,**q,reason=f'Fewer than {MIN_USABLE_ROWS} unambiguous fresh rows'));continue
        records.append(dict(**base,**q,**feats))
    df=pd.DataFrame(records);df.to_csv(a.output/'trial_features.csv',index=False);pd.DataFrame(excluded).to_csv(a.output/'excluded_trials.csv',index=False)
    meta=['trial','position','repeat','scenario','y','split','total_rows','usable_rows','usable_fraction'];cols=[c for c in df.columns if c not in meta]
    dev=df[df.split.eq('development')].reset_index(drop=True);test=df[df.split.eq('test')].reset_index(drop=True)
    assert set(dev.trial).isdisjoint(test.trial) and dev.repeat.isin([1,2]).all() and test.repeat.eq(3).all()
    assert np.isfinite(df[cols].to_numpy()).all()
    cv=[];oof=[];ranking=[]
    for name,factory in factories().items():
        pred=np.zeros(len(dev),int)
        for train,val in LeaveOneGroupOut().split(dev[cols],dev.y,groups=dev.repeat):
            model=factory();model.fit(dev.iloc[train][cols],dev.iloc[train].y);pred[val]=model.predict(dev.iloc[val][cols])
            cv.append(dict(model=name,validation_repeat=int(dev.iloc[val].repeat.iloc[0]),**metrics(dev.iloc[val].y,pred[val])))
        aggregate=metrics(dev.y,pred);ranking.append((aggregate['f1_fall'],aggregate['recall_fall'],name,aggregate))
        z=dev[['trial','y','repeat']].copy();z['prediction']=pred;z['model']=name;oof.append(z)
    # Select from development data only. The held-out set is evaluated once below.
    ranking.sort(key=lambda x:(x[0],x[1],x[2]=='RandomForest'),reverse=True);selected=ranking[0][2]
    fitted=factories()[selected]();fitted.fit(dev[cols],dev.y);pred=fitted.predict(test[cols])
    result=dict(task='Whole-recording scenario: contains simulated fall vs other scripted activity; not event timing or real-time alarm',height_proxy='z_mm=1700-x_mm, assuming positive X down',freshness_max_ms=MAX_BACKLOG_MS,min_usable_rows=MIN_USABLE_ROWS,feature_count=len(cols),feature_columns=cols,sklearn_version=sklearn.__version__,development_trials=len(dev),test_trials=len(test),development_fall_trials=int(dev.y.sum()),test_fall_trials=int(test.y.sum()),excluded_trials=excluded,selection='Best pooled F1 in leave-one-repeat-out development CV (01 vs 02); ties resolved by recall then RandomForest',development_cv_pooled={r[2]:r[3] for r in ranking},selected_model=selected,test=metrics(test.y,pred),majority_nonfall_baseline=metrics(test.y,np.zeros(len(test),int)),limitations=['One participant P01 and scripted recordings only','Folder descriptors supply whole-trial labels, not independent phase labels','Multi-target rows are excluded; single reported target does not independently establish the correct person','Features summarize an entire recording, including future samples; do not deploy as a sliding-window alarm','No measurement of individual event count, latency, or false alarms per hour','May learn scripted recording structure; requires a separate continuous-stream evaluation'])
    testpred=test[['trial','position','scenario','y','usable_rows','usable_fraction']].copy();testpred['prediction']=pred;testpred['correct']=testpred.y.eq(testpred.prediction);testpred.to_csv(a.output/'heldout_predictions.csv',index=False)
    pd.DataFrame(cv).to_csv(a.output/'development_cv_folds.csv',index=False);pd.concat(oof).to_csv(a.output/'development_oof_predictions.csv',index=False)
    (a.output/'metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    joblib.dump({'model':fitted,'feature_columns':cols,'task':'whole_trial_only','protocol':result},a.output/'whole_trial_baseline.joblib')
    print(json.dumps(result,ensure_ascii=False,indent=2));print(testpred.to_string(index=False))
if __name__=='__main__':main()
