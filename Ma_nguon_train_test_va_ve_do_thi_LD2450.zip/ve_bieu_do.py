"""Reproduce diagnostic plots with Matplotlib from raw CSVs and saved metrics.
These plots do not provide independent action-phase labels.
"""
from pathlib import Path
import argparse,json
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

CASES=['nga_mo_phong','nam_chu_dong','cui_nhat_do','dung_ngoi_nhanh']
LABELS=['Ngã mô phỏng','Nằm chủ động','Cúi nhặt đồ','Đứng–ngồi nhanh']
CASE_GROUPS=[
    (CASES,LABELS,'','Nhóm 1/2'),
    (['dung_yen','di_lai','dung_ngoi','ngoi_xom'],
     ['Đứng yên','Đi lại','Đứng–ngồi bình thường','Ngồi xổm'],'_nhom2','Nhóm 2/2'),
]

def plot_coordinates(root,out,repeat=1):
    for cases,labels,group_suffix,group_title in CASE_GROUPS:
        for coordinate in ['x_mm','y_mm']:
            fig,axes=plt.subplots(3,4,figsize=(16,9),sharey=True)
            for i,pos in enumerate('ABC'):
                for j,(act,label) in enumerate(zip(cases,labels)):
                    p=root/f'{pos}_direction'/f'{pos}_{act}_{repeat:02d}'/'samples.csv'
                    # C uses di_chuyen for the same walking scenario.
                    if not p.exists() and act=='di_lai':
                        p=root/f'{pos}_direction'/f'{pos}_di_chuyen_{repeat:02d}'/'samples.csv'
                    d=pd.read_csv(p);fresh=d.backlog_ms.le(500);f=d.loc[fresh]
                    if f.empty:raise ValueError(f'No fresh records in {p}')
                    t=(d.t_us-f.t_us.iloc[0])/1e6;ax=axes[i,j]
                    for slot,color in [(1,'#1d5aa6'),(2,'#c77918'),(3,'#8b4e9e')]:
                        y=d[f't{slot}_{coordinate}'].astype(float)/1000
                        y[~fresh|d[f't{slot}_active'].eq(0)]=np.nan
                        ax.plot(t,y,lw=.9,color=color,label=f'Ô mục tiêu {slot}')
                    ax.set_xlim(0,max(1,float(t[fresh].max())));ax.grid(alpha=.18)
                    if i==0:ax.set_title(label,fontweight='bold')
                    if j==0:ax.set_ylabel(f'Vị trí {pos}\nTọa độ {coordinate[0].upper()} (m)')
                    if i==2:ax.set_xlabel('Thời gian ESP32 từ khung mới đầu tiên (s)')
                    ax.text(.98,.95,p.parent.name,ha='right',va='top',fontsize=7,transform=ax.transAxes)
            handles,labs=axes[0,0].get_legend_handles_labels()
            fig.legend(handles,labs,loc='lower center',ncol=3,bbox_to_anchor=(.5,.005))
            fig.suptitle(f'Tọa độ {coordinate[0].upper()} radar — LẦN THU {repeat:02d} — {group_title} — A/B/C',fontsize=15,fontweight='bold',y=.99,va='top')
            fig.text(.5,.94,'Chỉ hiển thị bản ghi trễ gửi ≤ 500 ms. Ô mục tiêu 1/2/3 không phải lần thu 01/02/03. Tọa độ chưa phải chiều cao Z.',ha='center',va='top',fontsize=9)
            suffix='' if repeat==1 else f'_{repeat:02d}'
            fig.tight_layout(rect=(0,.035,1,.90));fig.savefig(out/f'traces_{coordinate[0]}{group_suffix}{suffix}.png',dpi=150);plt.close(fig)

def plot_empty_room(root,out):
    paths=sorted(root.glob('phong_trong/*/samples.csv'))
    if len(paths)!=3:raise ValueError(f'Expected 3 empty-room CSV files, found {len(paths)}')
    fig,axes=plt.subplots(3,1,figsize=(12,8),sharey=True)
    for ax,p in zip(axes,paths):
        d=pd.read_csv(p);fresh=d.backlog_ms.le(500)
        t=(pd.to_datetime(d.pc_time_utc)-pd.to_datetime(d.pc_time_utc.iloc[0])).dt.total_seconds()
        ax.plot(t,np.where(fresh,d.active_count,np.nan),color='#b23a30',lw=1.2)
        ax.fill_between(t,0,3,where=~fresh,color='#adb5bd',alpha=.4,label='Delayed >500 ms')
        ax.set_ylim(-.1,3.1);ax.set_yticks([0,1,2,3]);ax.set_ylabel('Reported targets')
        ax.grid(alpha=.2);ax.set_title(p.parent.name,loc='left',fontweight='bold')
    axes[-1].set_xlabel('PC elapsed time (s)');axes[0].legend(loc='upper right')
    fig.suptitle('Recordings named "empty room" still contain reported targets',fontsize=15,fontweight='bold')
    fig.tight_layout(rect=(0,0,1,.95));fig.savefig(out/'empty_room_targets.png',dpi=150);plt.close(fig)

def plot_confusion(results,out):
    m=json.loads((results/'metrics.json').read_text());cm=np.asarray(m['test']['confusion_matrix'])
    assert cm.shape==(2,2)
    fig,ax=plt.subplots(figsize=(7.5,5.5));ax.imshow(cm,cmap='Blues',vmin=0,vmax=max(1,int(cm.max())+1))
    ax.set_xticks([0,1],['Không ngã','Có ngã']);ax.set_yticks([0,1],['Không ngã','Có ngã'])
    ax.set_xlabel('Dự đoán theo toàn bộ lần thu');ax.set_ylabel('Nhãn kịch bản theo thư mục')
    for i in range(2):
        for j in range(2):ax.text(j,i,str(cm[i,j]),ha='center',va='center',fontsize=28,fontweight='bold',color='white' if cm[i,j]>.5*cm.max() else '#12324a')
    ax.set_title(f"Baseline {m['selected_model']}: đúng {int(np.trace(cm))}/{int(cm.sum())} file test\nTrain: 01/02 · Test giữ riêng: 03",fontsize=13,pad=15)
    fig.text(.5,.025,f"Chỉ phân loại cả lần thu; chưa đánh giá thời điểm báo ngã. Test có {m['test_fall_trials']} file ngã.",ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.06,1,1));fig.savefig(out/'confusion_matrix_trial_level.png',dpi=180);plt.close(fig)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--data-root',type=Path,required=True,help='Directory containing A_direction, B_direction, C_direction and phong_trong')
    ap.add_argument('--results',type=Path,required=True,help='Directory containing metrics.json from baseline_trial.py')
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--repeat',type=int,choices=[1,2,3],default=1,help='Recording repeat to plot: 1, 2 or 3 (report slots remain distinct)')
    a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False})
    plot_coordinates(a.data_root,a.output,a.repeat);plot_empty_room(a.data_root,a.output);plot_confusion(a.results,a.output)
    print(f'Saved 6 PNG plots (all 8 scenarios at repeat {a.repeat:02d}, plus diagnostics) to {a.output.resolve()}')
if __name__=='__main__':main()
