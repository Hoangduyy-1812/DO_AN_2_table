# HƯỚNG DẪN CODE, DỮ LIỆU TRAIN/TEST VÀ VẼ ĐỒ THỊ

## 1. Công cụ đã dùng

- Ngôn ngữ: Python. Môi trường đã chạy: Python 3.12.14.
- NumPy và pandas: đọc CSV, xử lý số liệu, tính đặc trưng.
- Matplotlib: tạo các hình traces_x.png, traces_y.png, empty_room_targets.png và confusion_matrix_trial_level.png.
- scikit-learn: RandomForestClassifier và SVC (SVM RBF); chuẩn hóa đầu vào SVM bằng StandardScaler trong Pipeline.
- joblib: lưu mô hình đã huấn luyện.

Các hình này được vẽ từ dữ liệu thực nghiệm bằng Python, không phải ảnh do AI vẽ hoặc kết quả MATLAB. Đồ thị X/Y là tọa độ radar báo về, chưa là Z đã biến đổi. Các màu biểu diễn slot mục tiêu, không phải danh tính người.

## 2. File train và file test chính xác là gì?

Dữ liệu đầu vào gốc nằm trong data(1).rar. Sau khi giải nén, mỗi lần thu là một thư mục chứa samples.csv, raw.ndjson, metadata.json và receiver_summary.json. Mỗi samples.csv tạo một mẫu đặc trưng ở cấp toàn bộ lần thu.

Ví dụ:

| Đường dẫn tương đối trong thư mục data | Vai trò |
|---|---|
| A_direction/A_nga_mo_phong_01/samples.csv | Train/development |
| A_direction/A_nga_mo_phong_02/samples.csv | Train/development |
| A_direction/A_nga_mo_phong_03/samples.csv | Test giữ riêng |
| B_direction/B_cui_nhat_do_01/samples.csv | Train/development |
| B_direction/B_cui_nhat_do_02/samples.csv | Train/development |
| B_direction/B_cui_nhat_do_03/samples.csv | Test giữ riêng |

Áp dụng cùng quy tắc cho 8 kịch bản ở A/B/C. File A_dung_ngoi_nhanh_01 bị loại khỏi phần phát triển theo tiêu chí ít nhất 100 khung mới chỉ có một slot hoạt động; thực tế file chỉ còn 17 khung đạt điều kiện. Sau lọc: 47 file development/train, 24 file test, không loại file test nào. Ba file phòng trống không dùng trong mô hình phân loại này vì nhãn thực tế/nguồn mục tiêu chưa xác minh.

Danh sách đầy đủ ở:

- 01_DANH_SACH/danh_sach_train_47.csv
- 01_DANH_SACH/danh_sach_test_24.csv
- 01_DANH_SACH/file_train_bi_loai.csv

Cột relative_samples_csv là đường dẫn tới đúng file gốc. Cột label_1_fall_0_nonfall: 1 = lần thu ngã mô phỏng; 0 = lần thu các hoạt động còn lại. Đây là nhãn của cả kịch bản/lần thu, không phải nhãn cho mọi thời điểm bên trong.

Không có một file gốc duy nhất tên train.csv hoặc test.csv. Chương trình đọc nhiều samples.csv rồi chia theo hậu tố của thư mục. Không cần tự di chuyển file sang thư mục train/test và không đổi tên hậu tố 01/02/03.

trial_features.csv là bảng đặc trưng đã tính: mỗi dòng ứng với một file, có cột split ghi development hoặc test. Thông tin tên file/vị trí/lượt không được đưa làm đặc trưng đầu vào mô hình.

## 3. Code train rồi test ở đâu?

baseline_trial.py chứa cả quy trình, theo thứ tự:

1. feature_vector(): đọc samples.csv, cách ly khung trễ >500 ms, bỏ dòng có nhiều slot hoạt động, tính Z_hat_mm=1700-X_mm theo giả thiết X dương xuống; tính 18 đặc trưng cho cả file. Không kẹp Z âm thành 0.
2. factories(): định nghĩa hai cấu hình mô hình cố định (Random Forest và SVM RBF).
3. main(): tách development từ 01/02 và test từ 03.
4. Trong development, luân phiên train 01/kiểm tra 02 và train 02/kiểm tra 01. StandardScaler chỉ fit trong phần train của từng lượt kiểm tra.
5. Chọn mô hình theo F1 trên các dự đoán kiểm tra phát triển gộp; không dùng 03 để chọn mô hình.
6. fitted.fit(dev[cols], dev.y): train mô hình được chọn trên toàn bộ 47 file development.
7. fitted.predict(test[cols]): dự đoán 24 file 03 được giữ riêng.
8. metrics(): so sánh dự đoán với nhãn kịch bản, tính Accuracy/Precision/Recall/F1 và confusion matrix.
9. Lưu mô hình bằng joblib.dump và xuất các bảng CSV/JSON.

Code của baseline_trial.py trong gói này được giữ nguyên so với bản đã tạo ra kết quả 23/24. Lần đóng gói này chỉ bổ sung hướng dẫn, danh sách và code vẽ; không tối ưu mô hình bằng tập test.

## 4. Cách chạy trên Windows

Dùng Python 3.11 hoặc 3.12; môi trường gốc chạy 3.12.14. requirements.txt ghim phiên bản thư viện đã dùng. Giải nén gói code và mở terminal ngay trong thư mục có baseline_trial.py.

Giả sử thư mục dữ liệu là D:\DoAn2\data, bên trong phải thấy:

- A_direction
- B_direction
- C_direction
- phong_trong

Cài thư viện:

```powershell
python -m pip install -r requirements.txt
```

Chạy train rồi test bằng một lệnh:

```powershell
python baseline_trial.py --data-root "D:\DoAn2\data" --output "D:\DoAn2\ket_qua"
```

Đổi đường dẫn ví dụ sang đường dẫn thật trên máy. Nếu giải nén tạo thêm lớp data/data, hãy chọn đúng thư mục trực tiếp chứa A_direction/B_direction/C_direction. Dữ liệu gốc không được nhúng vào gói code này; dùng data(1).rar đã có.

Vẽ đủ 72 lần thu: mỗi vị trí có một ảnh X và một ảnh Y, mỗi ảnh đủ 8 hàng hành vi × 3 cột lượt 01/02/03; kèm hai hình kiểm tra:

```powershell
python ve_bieu_do.py --data-root "D:\DoAn2\data" --results "D:\DoAn2\ket_qua" --output "D:\DoAn2\hinh"
```

Có thể vẽ lại từ kết quả đã kèm sẵn mà không train lại:

```powershell
python ve_bieu_do.py --data-root "D:\DoAn2\data" --results "02_KET_QUA_DA_CHAY" --output "hinh_ve_lai"
```

Code vẽ dùng Matplotlib. X/Y và số mục tiêu được đọc trực tiếp từ CSV; confusion matrix lấy số liệu trong metrics.json, không nhập tay để làm đẹp kết quả.

## 5. Những file xuất ra sau khi chạy train/test

| File | Ý nghĩa |
|---|---|
| trial_features.csv | Bảng 18 đặc trưng của từng file và cột split |
| excluded_trials.csv | File bị loại theo tiêu chí chất lượng, kèm lý do |
| development_cv_folds.csv | Kết quả từng lượt kiểm tra phát triển cho hai mô hình |
| development_oof_predictions.csv | Dự đoán kiểm tra phát triển trên từng file |
| heldout_predictions.csv | Đáp án, dự đoán, đúng/sai của 24 file test 03 |
| metrics.json | Các chỉ số và toàn bộ thông tin phép thử |
| whole_trial_baseline.joblib | Mô hình đã train và danh sách đặc trưng; không phải dữ liệu train |

02_KET_QUA_DA_CHAY là bản kết quả đã chạy trước đây để đối chiếu; 03_HINH_DA_VE là hình được tạo lại bằng code vẽ trong gói, hiện có đủ cả tám kiểu ở lượt 01/02/03.

## 6. Kết quả và phạm vi trình bày với giảng viên

- SVM: đúng 23/24 file test, Accuracy 95,83%, Precision lớp ngã 75%, Recall lớp ngã 3/3 file =100%, F1 lớp ngã 85,71%.
- File nhận sai: C_nam_chu_dong_03, nằm chủ động bị nhận thành ngã.
- F1 SVM khi kiểm tra phát triển là 66,67%; cần trình bày để phản ánh độ ổn định còn hạn chế.
- Nhãn là theo cả lần thu, lấy từ kịch bản đã thực hiện. Mỗi vector đặc trưng tóm tắt toàn bộ file nên dùng thông tin của cả đoạn đo.
- Kết quả này chưa đo từng sự kiện ngã, độ trễ hay báo động thời gian thực. Chưa chứng minh tổng quát hóa với người mới hoặc vị trí chưa có trong train.

Khi giải thích với giảng viên, cần nêu được: dữ liệu gốc, quy tắc chia file, công thức Z với chiều trục X, cách lọc khung, 18 đặc trưng, cách chọn mô hình và giới hạn đánh giá. Cần chạy lại code trên máy để tự kiểm chứng các bảng số liệu.




## 7. XEM ĐỦ 8 KIỂU × 3 LƯỢT × 3 VỊ TRÍ = 72 LẦN THU

MỞ THƯ MỤC 00_DU_72_LAN_THU. Bố cục chính được đổi sang theo vị trí, để thấy cả ba lượt ở cạnh nhau.

| Vị trí | Ảnh X | Ảnh Y | Số lần thu mỗi ảnh thể hiện |
|---|---|---|---:|
| A | VI_TRI_A_X_DU_8_HANH_VI_3_LUOT.png | VI_TRI_A_Y_DU_8_HANH_VI_3_LUOT.png | 24 |
| B | VI_TRI_B_X_DU_8_HANH_VI_3_LUOT.png | VI_TRI_B_Y_DU_8_HANH_VI_3_LUOT.png | 24 |
| C | VI_TRI_C_X_DU_8_HANH_VI_3_LUOT.png | VI_TRI_C_Y_DU_8_HANH_VI_3_LUOT.png | 24 |

Trong MỖI ảnh:

- 8 hàng: đứng yên, đi lại, đứng–ngồi bình thường, đứng–ngồi nhanh, cúi nhặt đồ, ngồi xổm, nằm chủ động, ngã mô phỏng.
- 3 cột: lượt 01, lượt 02, lượt 03. Cột 03 ghi TEST và được vẽ đầy đủ.
- Mỗi ô là đúng một lần thu và ghi tên thư mục CSV tương ứng.
- Màu xanh/cam/tím là các ô mục tiêu radar 1/2/3 trong một lần thu, không phải ba lượt thu.

A/B/C mỗi vị trí có 24 lần thu, tổng 72 lần. Sáu ảnh là hai tọa độ X/Y của cùng bộ 72 lần, không phải 144 lần thu khác nhau.

DANH_SACH_DU_72_LAN_THU_DA_VE.csv liệt kê 72 đường dẫn gốc đã vẽ. C đặt tên di_chuyen thay di_lai; code tự xử lý. File A_dung_ngoi_nhanh_01 vẫn được vẽ vì yêu cầu đủ 72 lần, nhưng trong mô hình baseline file đó bị loại do tiêu chí chất lượng; tiêu đề ô có ghi LOẠI KHỎI TRAIN.

Các bản bố cục cũ trong 00_HINH_DU_8_HANH_VI (theo từng lượt) và 03_HINH_DA_VE (chia nhóm bốn kiểu) được giữ để xem chi tiết. Để xem đúng yêu cầu đủ ba lượt trên cùng ảnh, ưu tiên mở 00_DU_72_LAN_THU.

### Code vẽ mặc định mới

Lệnh sau vẽ đủ cả A/B/C và cả ba lượt, không cần gọi --repeat ba lần:

```powershell
python ve_bieu_do.py --data-root "D:\DoAn2\data" --results "02_KET_QUA_DA_CHAY" --output "hinh_ve_lai"
```

Nếu chỉ muốn vẽ một vị trí:

```powershell
python ve_bieu_do.py --data-root "D:\DoAn2\data" --results "02_KET_QUA_DA_CHAY" --output "hinh_A" --position A
```

Mặc định --layout byposition và --position all. Trong bố cục này mỗi vị trí luôn bao gồm cả 01/02/03; --repeat không dùng để giới hạn lượt.

Các tùy chọn xem theo bố cục cũ: --layout all8 --repeat 3 (một lượt, cả A/B/C); --layout groups --repeat 3 (chia nhóm bốn kiểu); --layout both --repeat 3 (hai bố cục cũ).

Chỉ hiển thị bản ghi trễ gửi <=500ms và slot hoạt động; đoạn trống không được nội suy. Tọa độ X/Y trong ảnh chưa phải chiều cao Z đã biến đổi. Vẽ lượt 03 không đưa các mẫu đó vào train. Code train, mô hình và kết quả kiểm thử được giữ nguyên trong lần cập nhật này.
