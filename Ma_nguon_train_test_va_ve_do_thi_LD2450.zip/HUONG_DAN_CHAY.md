# HƯỚNG DẪN CODE, DỮ LIỆU TRAIN/TEST VÀ VẼ ĐỒ THỊ

## 1. Công cụ đã dùng

- Ngôn ngữ: Python. Môi trường đã chạy: Python 3.12.14.
- NumPy và pandas: đọc CSV, xử lý số liệu, tính đặc trưng.
- Matplotlib: tạo các hình traces_x.png, traces_y.png, empty_room_targets.png và confusion_matrix_trial_level.png.
- scikit-learn: RandomForestClassifier và SVC (SVM RBF); chuẩn hóa đầu vào SVM bằng StandardScaler trong Pipeline.
- joblib: lưu mô hình đã huấn luyện.

Các hình này được vẽ từ dữ liệu thực nghiệm bằng Python, không phải ảnh do AI vẽ hoặc kết quả MATLAB. Đồ thị X/Y là tọa độ radar báo về, chưa là Z đã biến đổi. Các màu biểu diễn slot mục tiêu, không phải danh tính người.

## 2. File train và file test chính xác là gì?

Dữ liệu đầu vào gốc nằm trong data(1).rar. Sau khi giải nén, mỗi lần thu là một thư mục chứa samples.csv, raw.ndjson, metadata.json và receiver_summary.json. Mỗi samples.csv tạo một mẫu đặc trưng ở cấp toàn bộ lần thu.

Ví dụ:

| Đường dẫn tương đối trong thư mục data | Vai trò |
|---|---|
| A_direction/A_nga_mo_phong_01/samples.csv | Train/development |
| A_direction/A_nga_mo_phong_02/samples.csv | Train/development |
| A_direction/A_nga_mo_phong_03/samples.csv | Test giữ riêng |
| B_direction/B_cui_nhat_do_01/samples.csv | Train/development |
| B_direction/B_cui_nhat_do_02/samples.csv | Train/development |
| B_direction/B_cui_nhat_do_03/samples.csv | Test giữ riêng |

Áp dụng cùng quy tắc cho 8 kịch bản ở A/B/C. File A_dung_ngoi_nhanh_01 bị loại khỏi phần phát triển theo tiêu chí ít nhất 100 khung mới chỉ có một slot hoạt động; thực tế file chỉ còn 17 khung đạt điều kiện. Sau lọc: 47 file development/train, 24 file test, không loại file test nào. Ba file phòng trống không dùng trong mô hình phân loại này vì nhãn thực tế/nguồn mục tiêu chưa xác minh.

Danh sách đầy đủ ở:

- 01_DANH_SACH/danh_sach_train_47.csv
- 01_DANH_SACH/danh_sach_test_24.csv
- 01_DANH_SACH/file_train_bi_loai.csv

Cột relative_samples_csv là đường dẫn tới đúng file gốc. Cột label_1_fall_0_nonfall: 1 = lần thu ngã mô phỏng; 0 = lần thu các hoạt động còn lại. Đây là nhãn của cả kịch bản/lần thu, không phải nhãn cho mọi thời điểm bên trong.

Không có một file gốc duy nhất tên train.csv hoặc test.csv. Chương trình đọc nhiều samples.csv rồi chia theo hậu tố của thư mục. Không cần tự di chuyển file sang thư mục train/test và không đổi tên hậu tố 01/02/03.

trial_features.csv là bảng đặc trưng đã tính: mỗi dòng ứng với một file, có cột split ghi development hoặc test. Thông tin tên file/vị trí/lượt không được đưa làm đặc trưng đầu vào mô hình.

## 3. Code train rồi test ở đâu?

baseline_trial.py chứa cả quy trình, theo thứ tự:

1. feature_vector(): đọc samples.csv, cách ly khung trễ >500 ms, bỏ dòng có nhiều slot hoạt động, tính Z_hat_mm=1700-X_mm theo giả thiết X dương xuống; tính 18 đặc trưng cho cả file. Không kẹp Z âm thành 0.
2. factories(): định nghĩa hai cấu hình mô hình cố định (Random Forest và SVM RBF).
3. main(): tách development từ 01/02 và test từ 03.
4. Trong development, luân phiên train 01/kiểm tra 02 và train 02/kiểm tra 01. StandardScaler chỉ fit trong phần train của từng lượt kiểm tra.
5. Chọn mô hình theo F1 trên các dự đoán kiểm tra phát triển gộp; không dùng 03 để chọn mô hình.
6. fitted.fit(dev[cols], dev.y): train mô hình được chọn trên toàn bộ 47 file development.
7. fitted.predict(test[cols]): dự đoán 24 file 03 được giữ riêng.
8. metrics(): so sánh dự đoán với nhãn kịch bản, tính Accuracy/Precision/Recall/F1 và confusion matrix.
9. Lưu mô hình bằng joblib.dump và xuất các bảng CSV/JSON.

Code của baseline_trial.py trong gói này được giữ nguyên so với bản đã tạo ra kết quả 23/24. Lần đóng gói này chỉ bổ sung hướng dẫn, danh sách và code vẽ; không tối ưu mô hình bằng tập test.

## 4. Cách chạy trên Windows

Dùng Python 3.11 hoặc 3.12; môi trường gốc chạy 3.12.14. requirements.txt ghim phiên bản thư viện đã dùng. Giải nén gói code và mở terminal ngay trong thư mục có baseline_trial.py.

Giả sử thư mục dữ liệu là D:\DoAn2\data, bên trong phải thấy:

- A_direction
- B_direction
- C_direction
- phong_trong

Cài thư viện:

```powershell
python -m pip install -r requirements.txt
```

Chạy train rồi test bằng một lệnh:

```powershell
python baseline_trial.py --data-root "D:\DoAn2\data" --output "D:\DoAn2\ket_qua"
```

Đổi đường dẫn ví dụ sang đường dẫn thật trên máy. Nếu giải nén tạo thêm lớp data/data, hãy chọn đúng thư mục trực tiếp chứa A_direction/B_direction/C_direction. Dữ liệu gốc không được nhúng vào gói code này; dùng data(1).rar đã có.

Vẽ lại bốn hình:

```powershell
python ve_bieu_do.py --data-root "D:\DoAn2\data" --results "D:\DoAn2\ket_qua" --output "D:\DoAn2\hinh"
```

Có thể vẽ lại từ kết quả đã kèm sẵn mà không train lại:

```powershell
python ve_bieu_do.py --data-root "D:\DoAn2\data" --results "02_KET_QUA_DA_CHAY" --output "hinh_ve_lai"
```

Code vẽ dùng Matplotlib. X/Y và số mục tiêu được đọc trực tiếp từ CSV; confusion matrix lấy số liệu trong metrics.json, không nhập tay để làm đẹp kết quả.

## 5. Những file xuất ra sau khi chạy train/test

| File | Ý nghĩa |
|---|---|
| trial_features.csv | Bảng 18 đặc trưng của từng file và cột split |
| excluded_trials.csv | File bị loại theo tiêu chí chất lượng, kèm lý do |
| development_cv_folds.csv | Kết quả từng lượt kiểm tra phát triển cho hai mô hình |
| development_oof_predictions.csv | Dự đoán kiểm tra phát triển trên từng file |
| heldout_predictions.csv | Đáp án, dự đoán, đúng/sai của 24 file test 03 |
| metrics.json | Các chỉ số và toàn bộ thông tin phép thử |
| whole_trial_baseline.joblib | Mô hình đã train và danh sách đặc trưng; không phải dữ liệu train |

02_KET_QUA_DA_CHAY là bản kết quả đã chạy trước đây để đối chiếu; 03_HINH_DA_VE là hình được tạo lại bằng code vẽ trong gói.

## 6. Kết quả và phạm vi trình bày với giảng viên

- SVM: đúng 23/24 file test, Accuracy 95,83%, Precision lớp ngã 75%, Recall lớp ngã 3/3 file =100%, F1 lớp ngã 85,71%.
- File nhận sai: C_nam_chu_dong_03, nằm chủ động bị nhận thành ngã.
- F1 SVM khi kiểm tra phát triển là 66,67%; cần trình bày để phản ánh độ ổn định còn hạn chế.
- Nhãn là theo cả lần thu, lấy từ kịch bản đã thực hiện. Mỗi vector đặc trưng tóm tắt toàn bộ file nên dùng thông tin của cả đoạn đo.
- Kết quả này chưa đo từng sự kiện ngã, độ trễ hay báo động thời gian thực. Chưa chứng minh tổng quát hóa với người mới hoặc vị trí chưa có trong train.

Khi giải thích với giảng viên, cần nêu được: dữ liệu gốc, quy tắc chia file, công thức Z với chiều trục X, cách lọc khung, 18 đặc trưng, cách chọn mô hình và giới hạn đánh giá. Cần chạy lại code trên máy để tự kiểm chứng các bảng số liệu.

## 7. Bổ sung đồ thị lần thu 02

Trong 03_HINH_DA_VE hiện có traces_x.png/traces_y.png cho lần 01 và traces_x_02.png/traces_y_02.png cho lần 02. Mỗi hình có 3 hàng A/B/C và 4 cột kịch bản. Các màu là ô mục tiêu 1/2/3 trong cùng lần thu, không phải ba lần thu.

Vẽ lượt 02 bằng lệnh:

```powershell
python ve_bieu_do.py --data-root "D:\DoAn2\data" --results "02_KET_QUA_DA_CHAY" --output "hinh_ve_lai" --repeat 2
```

Đổi --repeat thành 1 hoặc 3 để vẽ lượt tương ứng. Mặc định là lượt 01. Tên file lượt 01 giữ nguyên traces_x.png/traces_y.png; lượt 02/03 có hậu tố _02/_03. Code train/test, mô hình và kết quả được giữ nguyên; chỉ cập nhật code vẽ, hình và hướng dẫn.
